﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace up
{
    
    public partial class Услуги : Form
    {
        int r = 0, s, p;
        string ConnStr = @"Data Source=DESKTOP-PE7AIU9\SQLEXPRESS;Initial Catalog = 'Учебная_практика РученинАА'; Integrated Security = True";
        public Услуги()
        {
            InitializeComponent();
            FillУслуги();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                string SqlText = "insert into [Услуги] ([Код_услуги],[услуга],[цена]) VALUES (" + textBox1.Text + ", \'" + textBox2.Text + "\', " + textBox3.Text + ")";
                MyExecuteNonQuery(SqlText);
                FillУслуги();
            }
            else if (MyClass.должность == "laborant")
                MessageBox.Show("У вас недостаточно прав для редактирования таблицы.", "Внимание!");

            else if (MyClass.должность == "lab")
                MessageBox.Show("У вас недостаточно прав для редактирования таблицы.", "Внимание!");
        }

      

        private void button2_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                if (r == 0)
                {
                    int index, n;
                    string Код_услуги, услуга, цена;
                    n = dataGridView1.Rows.Count;
                    if (n == 1) return;
                    index = dataGridView1.CurrentRow.Index;
                    Код_услуги = dataGridView1[0, index].Value.ToString();
                    услуга = dataGridView1[1, index].Value.ToString();
                    цена = dataGridView1[2, index].Value.ToString();
                    textBox1.Text = Код_услуги;
                    textBox2.Text = услуга;
                    textBox3.Text = цена;
                    r = 1;
                }
                else if (r == 1)
                {
                    string SqlText = "update [Услуги] set Код_услуги = " + textBox1.Text + ", Услуга = \'" + textBox2.Text + "\', цена = " + textBox3.Text + " where Код_услуги = " + textBox1.Text;
                    MyExecuteNonQuery(SqlText);
                    FillУслуги();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    r = 0;
                }
            }
            else if (MyClass.должность == "lab")
                MessageBox.Show("У вас недостаточно прав для редактирования таблицы.", "Внимание!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                int index;
                string Код_услуги;
                index = dataGridView1.CurrentRow.Index;
                Код_услуги = Convert.ToString(dataGridView1[0, index].Value);
                string SqlText = "delete from [Услуги] WHERE Код_услуги = " + Код_услуги;
                MyExecuteNonQuery(SqlText);
                FillУслуги();
            }
            else if (MyClass.должность == "lab")
                MessageBox.Show("У вас недостаточно прав для редактирования таблицы.", "Внимание!");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox4.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
            }
        }

     

        

        private void Услуги_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "учебная_практика_РученинААDataSet.Услуги". При необходимости она может быть перемещена или удалена.
            this.услугиTableAdapter.Fill(this.учебная_практика_РученинААDataSet.Услуги);

        }

        private void FillУслуги()
        {
            string SqlText = null;
            if (p == 0)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Услуги]";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Услуги] order by услуга asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Услуги] order by услуга desc";
            }
            else if (p == 1)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Услуги]";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Услуги] where цена < 200 order by услуга asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Услуги] where цена < 200  order by услуга desc";
            }
            else if (p == 2)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Услуги]";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Услуги] where цена >= 200 order by услуга asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Услуги] where цена >= 200  order by услуга desc";
            }
            SqlDataAdapter da = new SqlDataAdapter(SqlText, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Услуги]");
            dataGridView1.DataSource = ds.Tables["[Услуги]"].DefaultView;
        }
        
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }
}

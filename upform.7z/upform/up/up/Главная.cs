﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace up
{
    public partial class Главная : Form
    {
        Thread vv;
        string ConnStr = @"Data Source=DESKTOP-PE7AIU9\SQLEXPRESS;Initial Catalog = 'Учебная_практика РученинАА'; Integrated Security = True";
        public Главная()
        {
            InitializeComponent();
            this.PassBox.AutoSize = false;
            this.PassBox.MaxLength = 15;
            this.LogBox.MaxLength = 15;
            this.LogBox.Size = new Size(this.LogBox.Size.Width, 30);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)     
        {
                if (checkBox1.Checked) { PassBox.UseSystemPasswordChar = true; }
                else { PassBox.UseSystemPasswordChar = false; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Логин, ФИО, Пароль;
            Логин = LogBox.Text;
            SqlCommand cmd;
            SqlConnection cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = "select должность from [Сотрудники] where \'" + Логин + "\' = логин";
            MyClass.должность = (string)cmd.ExecuteScalar();
            cmd.CommandText = "select фио from [Сотрудники] where \'" + Логин + "\' = логин";
            ФИО = (string)cmd.ExecuteScalar();
            cmd.CommandText = "select пароль from [Сотрудники] where \'" + Логин + "\' = логин";
            Пароль = (string)cmd.ExecuteScalar();
            cn.Close();

            if ((MyClass.должность == null) || (Пароль != PassBox.Text))
                
                
                    {
                MessageBox.Show("Неправильно введён логин или пароль, повторите ввод.", "Внимание!");
                this.Close();
                
                {
                    vv = new Thread(openVV);
                    vv.SetApartmentState(ApartmentState.STA);
                    vv.Start();
                }
                        
                    }

            else 
            {
                Пользователь f = new Пользователь();
                f.Show();
                if (MyClass.должность == "lab")
                {
                    f.label3.Text = "Лаборант";
                    f.label4.Text = ФИО;
                    f.pictureBox1.Visible = true;
                    f.pictureBox2.Visible = false;
                    f.pictureBox3.Visible = false;


                }
                else if (MyClass.должность == "laborant")
                {
                    f.label3.Text = "Лаборант";
                    f.label4.Text = ФИО;
                    f.pictureBox1.Visible = false;
                    f.pictureBox2.Visible = false;
                    f.pictureBox3.Visible = true;
                }
                else if (MyClass.должность == "admin")
                {
                    f.label3.Text = "Администратор";
                    f.label4.Text = ФИО;
                    f.pictureBox1.Visible = false;
                    f.pictureBox2.Visible = true;
                    f.pictureBox3.Visible = false;

                }
            }
        }


        //elnard32 WhtpSgj89
        //hoody27 hTdgOj296
        //brook13 friw9Tejd
        //michael9 pghaYiw2Js3
        public void openVV(object obj)
        { Application.Run(new Капча()); }
    }
    class MyClass
    {
        public static string должность { get; set; }
    }
}

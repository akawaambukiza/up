﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace up
{
    public partial class Пользователь : Form
    {
        string ConnStr = @"Data Source=DESKTOP-PE7AIU9\SQLEXPRESS;Initial Catalog = 'Учебная_практика РученинАА'; Integrated Security = True";
        public Пользователь()
        {
            InitializeComponent();
        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();

        }
        private void Выход_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Услуги_Click(object sender, EventArgs e)
        {
            Услуги f = new Услуги();
            f.Show();
        }

        private void Пациенты_Click(object sender, EventArgs e)
        {
            Пациенты f = new Пациенты();
            f.Show();
        }

        private void Результаты_Click(object sender, EventArgs e)
        {
            Результаты f = new Результаты();
            f.Show();
        }

        private void Сотрудники_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                Сотрудники f = new Сотрудники();
                f.Show();
            }
            else if (MyClass.должность == "laborant")
                MessageBox.Show("У вас недостаточно прав для просмотра", "Внимание!");
            else if (MyClass.должность == "lab")
                MessageBox.Show("У вас недостаточно прав для просмотра", "Внимание!");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            label6.Text = (DateTime.Now.ToLongTimeString());
            Refresh();
        }
    }
}


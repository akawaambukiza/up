﻿using BarcodeLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace up
{
    public partial class Результаты : Form
    {
        int r = 0, s, p;
        string ConnStr = @"Data Source=DESKTOP-PE7AIU9\SQLEXPRESS;Initial Catalog = 'Учебная_практика РученинАА'; Integrated Security = True";
        public Результаты()
        {
            InitializeComponent();
            FillРезультаты();
        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index, n;
            n = dataGridView1.Rows.Count;
            if (n == 1) return;
            index = dataGridView1.CurrentRow.Index;

            Barcode code = new Barcode();
            Image img = code.Encode(TYPE.UPCA, dataGridView1[0, index].Value.ToString());
            pictureBox1.Image = img;
        }

     

        private void button2_Click(object sender, EventArgs e)
        {
            int index;
            string id;
            index = dataGridView1.CurrentRow.Index;
            id = Convert.ToString(dataGridView1[0, index].Value);
            string SqlText = "delete from [Results] WHERE id = " + id;
            MyExecuteNonQuery(SqlText);
            FillРезультаты();
        }
        
        

        private void FillРезультаты()
        {
            string SqlText = null;
            if (p == 0)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Результаты]";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Результаты] order by data asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Результаты] order by data desc";
            }
            else if (p == 1)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Результаты] where result = \'+\'";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Результаты] where result = \'+\' order by data asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Результаты] where result = \'+\'  order by data desc";
            }
            else if (p == 2)
            {
                if (s == 0)
                    SqlText = "SELECT * FROM [Results] where result = \'-\'";
                else if (s == 1)
                    SqlText = "SELECT * FROM [Results] where result = \'-\' order by data asc";
                else if (s == 2)
                    SqlText = "SELECT * FROM [Results] where result = \'-\'  order by data desc";
            }
            SqlDataAdapter da = new SqlDataAdapter(SqlText, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Результаты]");
            dataGridView1.DataSource = ds.Tables["[Результаты]"].DefaultView;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string SqlText = "insert into [Результаты] ([id],[id_user],[id_lab],[id_service],[result],[data]) VALUES (\'" + textBox7.Text + "\', " + textBox1.Text + ", " + textBox2.Text + ", " + textBox3.Text + ", \'" + textBox4.Text + "\', \'" + textBox5.Text + "\')";
            MyExecuteNonQuery(SqlText);
            FillРезультаты();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox7.Text = "";
        }
    }
}

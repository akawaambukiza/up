﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace up
{
    public partial class Сотрудники : Form
    {
        int r = 0, s, p;
        string ConnStr = @"Data Source=DESKTOP-PE7AIU9\SQLEXPRESS;Initial Catalog = 'Учебная_практика РученинАА'; Integrated Security = True";

        private void Сотрудники_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "учебная_практика_РученинААDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.учебная_практика_РученинААDataSet.Сотрудники);

        }

        public Сотрудники()
        {
            InitializeComponent();
            FillСотрудники();
        }


        public void MyExecuteNonQuery(string SqlText)
        {
           SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
           cmd.ExecuteNonQuery();
           cn.Close();
        }

        private void FillСотрудники()
       {
            string SqlText = null;
            
          if (MyClass.должность == "admin")
            {
                if (p == 0)
                {
                    if (s == 0)
                        SqlText = "SELECT * FROM [Сотрудники]";
                    else if (s == 1)
                        SqlText = "SELECT * FROM [Сотрудники] order by ФИО asc";
                    else if (s == 2)
                        SqlText = "SELECT * FROM [Сотрудники] order by ФИО desc";
                }
                
                else if (p == 1)
               {
                    if (s == 0)
                        SqlText = "SELECT * FROM [Сотрудники] where должность = \'admin\'";
                    else if (s == 1)
                        SqlText = "SELECT * FROM [Сотрудники] where должность = \'admin\' order by ФИО asc";
                    else if (s == 2)
                        SqlText = "SELECT * FROM [Сотрудники] where должность = \'admin\' order by ФИО desc";
                }
            }
            SqlDataAdapter da = new SqlDataAdapter(SqlText, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Сотрудники]");
            dataGridView1.DataSource = ds.Tables["[Сотрудники]"].DefaultView;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                int index, n;
                string Код_сотрудника;
                index = dataGridView1.CurrentRow.Index;
                Код_сотрудника = Convert.ToString(dataGridView1[0, index].Value);
                string SqlText = "delete from [Сотрудники] WHERE Код_сотрудника = " + Код_сотрудника;
                MyExecuteNonQuery(SqlText);
               FillСотрудники();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MyClass.должность == "admin")
            {
                int index, n;
                n = dataGridView1.Rows.Count;
                if (n == 1) return;
                index = dataGridView1.CurrentRow.Index;
                string Код_сотрудника = dataGridView1[0, index].Value.ToString();
                if (r == 0)
                {
                    string ФИО, логин, пароль, ip, ДатаВхода, должность, анализатор;
                    ФИО = dataGridView1[1, index].Value.ToString();
                    логин = dataGridView1[2, index].Value.ToString();
                    пароль = dataGridView1[3, index].Value.ToString();
                    ip = dataGridView1[4, index].Value.ToString();
                    ДатаВхода = dataGridView1[5, index].Value.ToString();
                    должность = dataGridView1[6, index].Value.ToString();
                    анализатор = dataGridView1[7, index].Value.ToString();
                    textBox1.Text = ФИО;
                    textBox2.Text = логин;
                    textBox3.Text = пароль;
                    textBox4.Text = ip;
                    textBox5.Text = ДатаВхода;
                    textBox8.Text = должность;
                    textBox7.Text = анализатор;
                    r = 1;
                }
                else if (r == 1)
                {
                    string SqlText = "update [Сотрудники] set ФИО = \'" + textBox1.Text + "\', логин = \'" + textBox2.Text + "\', пароль = \'" + textBox3.Text + "\', ip = \'" + textBox4.Text + "\', ДатаВхода = \'" + textBox5.Text + "\', должность = \'" + textBox8.Text + "\', анализатор = \'" + textBox7.Text + "\' where Код_сотрудника = " + Код_сотрудника;
                    MyExecuteNonQuery(SqlText);
                    FillСотрудники();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox8.Text = "";
                    textBox7.Text = "";
                    r = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != "") || (textBox2.Text != "") || (textBox3.Text != "") || (textBox4.Text != "") || (textBox5.Text != "") || (textBox8.Text != ""))
            {
                if (MyClass.должность == "admin")
                {
                    string SqlText = "insert into [Сотрудники] ([ФИО],[логин],[пароль],[ip],[ДатаВхода], [Должность], [Анализатор]) VALUES (\'" + textBox1.Text + "\', \'" + textBox2.Text + "\', \'" + textBox3.Text + "\', \'" + textBox4.Text + "\', \'" + textBox5.Text + "\', \'" + textBox8.Text + "\', \'" + textBox7.Text + "\')";
                    MyExecuteNonQuery(SqlText);
                    FillСотрудники();
                }
            }
        }
}
}
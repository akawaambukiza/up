﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace up
{
    public partial class Капча : Form
    {
        Thread vv;
        int num = 0;
        public Капча()
        {
            InitializeComponent();
            this.textBox1.MaxLength = 3;
            loadcaptcha();
        }

        private void loadcaptcha()
        {
            Random r1 = new Random();
            num = r1.Next(100, 999);
            var img = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            var font = new Font("Comic Sans MS", 30, FontStyle.Bold, GraphicsUnit.Pixel);
            var graphics = Graphics.FromImage(img);
            graphics.DrawString(num.ToString(), font, Brushes.Red, new Point(115, 45));
            pictureBox1.Image = img;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == num.ToString())
            {
                this.Close();
                vv = new Thread(openVV);
                vv.SetApartmentState(ApartmentState.STA);
                vv.Start();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadcaptcha();
        }
        public void openVV(object obj)
        { Application.Run(new Главная()); }
    }
}
